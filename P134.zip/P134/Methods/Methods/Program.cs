﻿using System;

namespace Methods
{
    internal class Program
    {

        static void Main(string[] args)
        {
            #region methods
            //Console.WriteLine(Sum(5,6));

            // Sum-i cagirdigimiz yerde gonderdiyimiz deyerler argumentler adlanir
            //int result = Sum(4, 5);
            //Console.WriteLine(result);

            //Console.WriteLine(Info("Ugur", "Qasimov",25,true));

            //GetInfo();
            //Console.WriteLine(CheckIsMarried(false));

            //Console.WriteLine(GetResult());
            #endregion
            #region default
            //Console.WriteLine(GetFullInfo());
            //Console.WriteLine(GetFullInfo("Ugur", "Qasimov", 19,"Baki"));
            #endregion
            #region method signature
            //method signature:
            // 1.methodun adi
            // 2.methudun parametrlerinin sayi
            // 3.methodun parametrlerinin data typy-i
            // Console.WriteLine(Sum(2,3));
            int[] numbers = { 1, 2, 3 };

            Console.WriteLine(SummArray(numbers));
            #endregion

            Console.WriteLine(SumOdd(1,2,3));
        }

        #region methods
        //Sum-declare etdiymiz yerde gonderdeyimiz deyer parametrler adlanir
        //static int Sum(int num1,int num2)
        //{
        //    return num1+ num2;
        //}

        //static string Info(string name,string surname,int age,bool isMarried)
        //{
        //    //return name + " " + surname +age ;
        //    return $"{name} {surname} {age} evlidirmi {isMarried}";

        //}
        //static void GetInfo()
        //{
        //    int sum = 0;
        //    for (int i = 0; i < 10; i++)
        //    {
        //        sum +=i;
        //    }
        //}

        //static bool CheckIsMarried(bool isMarried)
        //{
        //    return isMarried;
        //}

        static int GetResult()
        {
            int num1 = 15;
            int num2 = 10;
            if (num1 > num2)
            {
                return num1 - num2;
            }
            else
            {
                return num1 + num2;
            }
        }
        #endregion

        #region default
        //static string GetFullInfo(string name="Lorem",string surname="ipsum",int age=20,string address="Sumqayit")
        //{
        //    return $"{name} {surname} {age} {address}";
        //}
        #endregion

        #region method signature
        //eyni adli muxtelif methodlarin varligi method overloading adlanir

        static int Sum(int num1, int num2, int age = 25)
        {
            return num1 + num2;
        }
        static int Sum(int num1, int num2)
        {
            return num1 + num2;
        }

        static int SummArray(int[] arr)
        {
            int sum = 0;
            foreach (int item in arr)
            {
                sum += item;
            }
            return sum;
        }
        #endregion

        
        static int SumOdd(params int[] arr)
        {
            int sum = 0;
            
            foreach (int item in arr)
            {
                if (item%2==1)
                {
                    sum += item;
                }

            }
            return sum;
        }




    }

}
