﻿using System;

namespace Loops
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int sum = 0;

            //for (int i=1;i<=10;i++)
            //{
            //    sum += i; //sum=sum+i
            //}


            //Console.WriteLine(sum);


            //int sum = 0;
            //int n = 5;
            //int m = 55;

            //for (int i = n; i <= m; i++)
            //{
            //    sum += n; //sum=sum+i
            //}


            //Console.WriteLine(sum);


            //int sum = 0;
            //int n = 50;
            //int m = 100;
            //for(int i = n; i <= m; i++)
            //{
            //    if (i%2==0)
            //    {
            //        sum += i;
            //        //50+52
            //    }
            //}

            //Console.WriteLine(sum);

            //int n = 1;
            //int m = 100;
            //int multi = 1;
            //for (int i = n; i < m; i++)
            //{
            //    if (i % 13 == 0)
            //    {
            //        multi *= i;
            //    }
            //}
            //Console.WriteLine(multi);
            //for (; ; )
            //{
            //    Console.WriteLine("SALAM");
            //}
            //int i = 1;
            //while (i<100)
            //{

            //    Console.WriteLine(i);
            //    i++;
            //}


            //int num = 10;
            //do
            //{
            //    Console.WriteLine(num);
            //    num++;
            //} while (num<100);

            //for (int i = 100; i>0; i--)
            //{
            //    Console.WriteLine(i);
            //}
            int num = 5555;
            int mertebe = 0;
            while (num>1)
            {
                num /= 10;
                mertebe++;
            }
            Console.WriteLine(mertebe);
        }
    }     
}
