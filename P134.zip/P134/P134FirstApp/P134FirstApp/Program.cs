﻿using System;

namespace P134FirstApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region myfirstcode
            //int num1 = 23;
            //int num2 = 20;

            //int age = 19;

            //bool isMarried = false;
            //string name = "David";

            //Console.WriteLine(num1);


            //int MyAge = 55;
            //string myName = "Ulvi";
            //string my_car = "bmw";


            #endregion

            #region userInfo    
            string huseynsName = "Huseyn";
            string huseynsSurnam = "Huseynli";
            int age = 19;
            string adress = "Baki Xatai 12";
            char symbol = '*';
            bool isMarried = false;


            int number = 2;
            int number2 = 13;
            Console.WriteLine(number%number2);
            

            #endregion




































        }
    }
}
