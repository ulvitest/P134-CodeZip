﻿using System;
using System.Text;

namespace ReferenceValueTypes
{
    internal class Program
    {

        static void Main(string[] args)
        {
            #region task
            //Console.WriteLine(Factorial(3));
            #endregion

            #region reference value
            int num1 = 5;
            int num2 = num1; //num2=5;
            num2 = 10;
            //Console.WriteLine($"num1={num1}");
            //Console.WriteLine($"num2={num2}");

            //int[] arr1 = { 1, 2, 3 };
            //int[] arr2 = arr1;
            //arr1[0] = 55;
            //Console.WriteLine($"arr1[0]={arr1[0]}");
            //Console.WriteLine($"arr2[0]={arr2[0]}");


            //value
            //int a = 10;
            //ChangeNum(a);

            //reference
            //int[] numbers = { 1, 2, 3 };
            //ChangeArr(numbers);
            //Console.WriteLine(numbers[0]);

            //ref out

            //int a=10;
            //ChangeNum(ref a);
            //Console.WriteLine(a);

            #endregion

            #region string

            //string name1 = "Fikret";
            //string name2 = name1;
            //string name3 = "Fikret";
            //name2 = "Lorem";
            //Console.WriteLine($"name1 {name1}");
            //Console.WriteLine($"name2 {name2}");
            //Console.WriteLine(name1==name3);
            //string word = "          LOREM   ";


            //string word2 = "lorem";
            //Console.WriteLine(word.ToLower()==word2.ToLower());
            //Console.WriteLine(word.Length);
            //Console.WriteLine(word.ToLower());
            //Console.WriteLine(word);
            //Console.WriteLine(word.ToUpper());
            //Console.WriteLine(word.TrimEnd());

            string name1 = "LoLem";
            string name2 = "lorem";
            //Console.WriteLine(String.Compare(name2, name1));
            //Console.WriteLine(name1.Replace("L","T"));
            //Console.WriteLine(name1.Contains("L"));
            //Console.WriteLine(name1.LastIndexOf("L"));

            //string[] names = {"Semed","Lorem","Ugur" };
            //string word = "loremipsumdoler";
            //string[] newArr= word.Split("");
            //foreach (var item in newArr)
            //{
            //    Console.WriteLine(item);
            //}

            Console.WriteLine(ChangeWord("Lorem"));

            #endregion

        }

        #region task
        static long Factorial(int num)
        {
            long sum = 1;
            for (int i = 1; i <=num; i++)
            {
                sum *= i;
            }
            return sum;
        }
        #endregion

        #region ref out
        static void ChangeNum(ref int b)
        {
            //b = 55;
            Console.WriteLine(b);
        }

        static void ChangeArr(int[]arr)
        {
            arr[0] = 55;
            Console.WriteLine(arr[0]);
        }
        #endregion

        static string ChangeWord(string word)
        {
            StringBuilder result =new StringBuilder();
            for (int i =word.Length-1; i >=0; i--)
            {
                result.Append(word[i]);
            }
            return result.ToString();
        }
    }
}
