﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassInheritance
{
    class Student:Person
    {
       
        public int grade;

        //constructor 
        //1.class ile eyni adlidir
        //2.return type yoxdur
        //3.instance yaradilanda ishe dusur
        public Student():base("lorem")
        {
            Console.WriteLine("salam");
        }
        public Student(string n,string s):this()
        {
            name = n;
            surname = s;
        }

        public Student(string n, string s,int a):this(n,s)
        {
            age = a;
        }

       

        public string FullInfo()
        {
            return $"{Info()} age: {age} grade {grade}";
        }
    }
}
