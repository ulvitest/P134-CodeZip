﻿using System;

namespace ClassInheritance
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //users
            #region class object
            //string name1 = "Hesen";
            //string surname = "Cebrayilov";
            //int age1 = 18;
            //bool isMaried1=false;
            //string address1 = "Baki";

            //string name2 = "Cavid";
            //string surnam2 = "Memmedli";
            //int age2 = 22;
            //bool isMaried2 = false;

            //string name3 = "Lorem";
            //string surnam3 = "Ipsum";
            //int age3 = 22;
            //bool isMaried3 = false;

            //var obj1 = new
            //{
            // name="Lorem",
            // surname="Ipsum",
            // age=25,
            // address="Baki"
            //};
            

            //var obj2 = new
            //{
            //    name = "Lorem1",
            //    surname = "Ipsum1",
            //    age = 26

            //};

            //Console.WriteLine($"object 1 name: {obj1.name} age : {obj1.surname}");
            //Console.WriteLine($"object 2 name: {obj2.name} age : {obj2.surname}");
            #endregion

            //instance
            //Student stu1=new Student();
            //stu1.name = "Lorem";
            //stu1.surname = "Ipsum";
            //stu1.age = 20;
            //stu1.address = "Baki";
            //stu1.grade = 55;
            //Console.WriteLine(stu1.Info());
            //Console.WriteLine(stu1.FullInfo());

            //Student stu2=new Student("Cavid","Memmedli");
            //stu2.name = "blablabla";
            //stu2.age = 21;
            //stu2.address = "Sumqayit";
            //stu2.grade = 56;
            //Console.WriteLine(stu2.FullInfo());
            //stu2.Info();
            Student stu3 = new Student("Nuran","Hesenov",19);
            stu3.address = "Sheki";
            stu3.grade = 20;
            //Console.WriteLine(stu3.FullInfo());

            //Teacher teacher = new Teacher();
            //teacher.name = "Lorem";
            //teacher.surname = "ipsum";
            //teacher.address = "Baki";
            //teacher.profession = "Kimya";
            //Console.WriteLine(teacher.Info());




        }
    }
    
}
