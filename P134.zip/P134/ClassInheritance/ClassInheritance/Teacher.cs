﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassInheritance
{
    internal class Teacher:Person
    {

       public string profession;
        public Teacher():base("")
        {

        }
    }
}
