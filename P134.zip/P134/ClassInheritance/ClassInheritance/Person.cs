﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassInheritance
{
    internal class Person
    {
        public string name;
        public string surname;
        public int age;
        public string address;

        public Person(string n)
        {

        }
        public string Info()
        {
            return $"name: {name} surname: {surname}";
        }

    }
}
