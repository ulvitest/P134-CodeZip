﻿using System;

namespace ConsoleIntro
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int age = 25;
            //string name = "Lorem";

            //int num1 = 4;
            //int num2 = 7;

            //num1=num1 + num2;// num1=11
            //num2 = num1 - num2; //num2=4
            //num1=num1 - num2; //num1=7;

            //Console.WriteLine(num1);
            //Console.WriteLine(num2);

            //int age = 16;
            //if (age>16)
            //{
            //    Console.WriteLine("okaydir");
            //}
            //else if (age == 16)
            //{
            //    Console.WriteLine("hele boyumelisen");
            //}
            //else
            //{
            //    Console.WriteLine("okay deyil");
            //}

            //int age = 1;
            //switch (age)
            //{
            //    case 15:
            //        Console.WriteLine("yash 15dir");
            //        break;
            //    case 14:
            //        Console.WriteLine("yash 14 dir");
            //        break;
            //    default:
            //        Console.WriteLine("hecbiri");
            //        break;

            //}

            //int weekDay = 4;
            //switch (weekDay)
            //{
            //    case 1:
            //    case 2:
            //    case 3:
            //        Console.WriteLine("1 2 veya 3cigun");
            //        break;

            //    default:
            //        Console.WriteLine("hecbiri");
            //        break;
            //}

            int[] numbers = { 5, 6, 8, 9, 7, 4 };
            //for (int i = 0; i < numbers.Length; i++)
            //{
            //    Console.WriteLine(numbers[i]);
            //}
            //int sum = 0;
            //foreach (int item in numbers)
            //{
            //    sum += item;
            //}
            //Console.WriteLine(sum);


            //string[] names = { "Sabir", "Semed", "Nuran" };
            //foreach (string item in names)
            //{
            //    if (item=="Semed")
            //    {
            //        break;
            //    }

            //        Console.WriteLine(item);


            //}
            //double num = 4567777777777777777;
            //int count = 0;

            //while (num>=1)
            //{
            //     num /= 10;
            //    count++;
            //}
            //Console.WriteLine(count);
            int num = 3;
            int sum = 0;
            do
            {
                sum += num;
                //1ci sum 3 num 2
                //2ci sum 5 num 1
                num--;
            } while (num>1);
            Console.WriteLine(sum);
           
        }

    }
}
